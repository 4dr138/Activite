<?php

namespace OpenClassrooms\CoreBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class OpenClassroomsCoreBundle extends Bundle
{
}
