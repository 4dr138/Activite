<?php

namespace Activite\CoreBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ActiviteCoreBundle extends Bundle
{
}
